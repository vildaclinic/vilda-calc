#!/usr/bin/env node
'use strict';

/*
 * Vilda 8P-2 — PWA manifest/start_url/scope/icon cache smoke.
 * Static, read-only audit: reads manifest.json, HTML, icon files and service-worker-kalorii.js.
 * Does not register a Service Worker, does not touch browser Cache API/IndexedDB and does not perform network fetches.
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const STEP = '8P-2';
const EXPECTED_SW_VERSION = '0.9.408';
const EXPECTED_MANIFEST_ICON_PATHS = [
  'pwa-icons/icon-40x40.png',
  'pwa-icons/icon-48x48.png',
  'pwa-icons/icon-58x58.png',
  'pwa-icons/icon-60x60.png',
  'pwa-icons/icon-72x72.png',
  'pwa-icons/icon-76x76.png',
  'pwa-icons/icon-80x80.png',
  'pwa-icons/icon-87x87.png',
  'pwa-icons/icon-96x96.png',
  'pwa-icons/icon-114x114.png',
  'pwa-icons/icon-120x120.png',
  'pwa-icons/icon-128x128.png',
  'pwa-icons/icon-136x136.png',
  'pwa-icons/icon-144x144.png',
  'pwa-icons/icon-152x152.png',
  'pwa-icons/icon-167x167.png',
  'pwa-icons/icon-180x180.png',
  'pwa-icons/icon-192x192.png',
  'pwa-icons/icon-256x256.png',
  'pwa-icons/icon-384x384.png',
  'pwa-icons/icon-512x512-maskable.png',
  'pwa-icons/icon-512x512.png',
  'pwa-icons/icon-1024x1024.png'
];
const EXPECTED_BROWSER_ICON_PATHS = [
  'pwa-icons/icon-48x48.png',
  'pwa-icons/icon-96x96.png',
  'pwa-icons/icon-144x144.png',
  'pwa-icons/icon-512x512.png'
];

function readText(rel) { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function readJson(rel) { return JSON.parse(readText(rel)); }
function exists(rel) { return fs.existsSync(path.join(ROOT, rel)); }
function add(checks, id, ok, details) { checks.push({ id, ok: !!ok, details: details || null }); }
function parseSizeToken(token) {
  const match = String(token || '').match(/^(\d+)x(\d+)$/);
  return match ? { width: Number(match[1]), height: Number(match[2]) } : null;
}
function readPngDimensions(rel) {
  const file = path.join(ROOT, rel.replace(/^\//, ''));
  const buf = fs.readFileSync(file);
  if (buf.length < 24 || buf.toString('ascii', 1, 4) !== 'PNG') return null;
  return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
}
function iconSrcToRel(src) { return String(src || '').replace(/^\//, ''); }
function isInRootScope(url) {
  const value = String(url || '');
  return value.charAt(0) === '/' && value.indexOf('//') !== 0;
}

function runPwaManifestIconCacheSmoke() {
  const checks = [];
  const manifest = readJson('manifest.json');
  const sw = readText('service-worker-kalorii.js');
  const indexHtml = readText('index.html');
  const docproHtml = readText('docpro.html');

  add(checks, 'manifest-start-url-scope-root', manifest.id === '/' && manifest.start_url === '/' && manifest.scope === '/', {
    id: manifest.id,
    start_url: manifest.start_url,
    scope: manifest.scope
  });

  const shortcuts = Array.isArray(manifest.shortcuts) ? manifest.shortcuts : [];
  const shortcutUrls = shortcuts.map((item) => item && item.url).filter(Boolean);
  const externalShortcutUrls = shortcutUrls.filter((url) => !isInRootScope(url));
  add(checks, 'manifest-shortcuts-in-scope', shortcutUrls.length >= 4 && externalShortcutUrls.length === 0 && shortcutUrls.includes('/kontakt.html'), {
    shortcutUrls,
    externalShortcutUrls
  });

  const icons = Array.isArray(manifest.icons) ? manifest.icons : [];
  const iconPaths = icons.map((icon) => iconSrcToRel(icon.src));
  const missingIconDeclarations = EXPECTED_MANIFEST_ICON_PATHS.filter((rel) => !iconPaths.includes(rel));
  add(checks, 'manifest-declares-expected-icons', icons.length === EXPECTED_MANIFEST_ICON_PATHS.length && missingIconDeclarations.length === 0, {
    iconCount: icons.length,
    missingIconDeclarations
  });

  const iconFileDetails = icons.map((icon) => {
    const rel = iconSrcToRel(icon.src);
    const expectedSize = parseSizeToken(icon.sizes);
    const fileExists = exists(rel);
    let dimensions = null;
    if (fileExists && String(icon.type || '').toLowerCase() === 'image/png') {
      dimensions = readPngDimensions(rel);
    }
    return {
      src: rel,
      declaredSize: icon.sizes,
      purpose: icon.purpose || 'any',
      exists: fileExists,
      dimensions,
      sizeMatches: !!(expectedSize && dimensions && dimensions.width === expectedSize.width && dimensions.height === expectedSize.height)
    };
  });
  const badIconFiles = iconFileDetails.filter((item) => !item.exists || !item.sizeMatches);
  add(checks, 'manifest-icon-files-exist-with-declared-dimensions', badIconFiles.length === 0, {
    checkedCount: iconFileDetails.length,
    badIconFiles
  });

  const has192 = iconFileDetails.some((item) => item.declaredSize === '192x192' && item.exists && item.sizeMatches);
  const has512 = iconFileDetails.some((item) => item.declaredSize === '512x512' && item.exists && item.sizeMatches && item.purpose !== 'maskable');
  const hasMaskable512 = iconFileDetails.some((item) => item.declaredSize === '512x512' && item.exists && item.sizeMatches && String(item.purpose).indexOf('maskable') >= 0);
  add(checks, 'manifest-installable-icon-sizes', has192 && has512 && hasMaskable512, { has192, has512, hasMaskable512 });

  const missingBrowserIcons = EXPECTED_BROWSER_ICON_PATHS.filter((rel) => !exists(rel));
  add(checks, 'browser-icon-files-exist-in-pwa-icons', missingBrowserIcons.length === 0, { expected: EXPECTED_BROWSER_ICON_PATHS, missingBrowserIcons });

  const htmlChecks = [
    { file: 'index.html', html: indexHtml },
    { file: 'docpro.html', html: docproHtml }
  ].map((item) => ({
    file: item.file,
    manifestRootAbsolute: item.html.includes('rel="manifest" href="/manifest.json"'),
    touch120: item.html.includes('href="/pwa-icons/icon-120x120.png"'),
    touch152: item.html.includes('href="/pwa-icons/icon-152x152.png"'),
    touch167: item.html.includes('href="/pwa-icons/icon-167x167.png"'),
    touch180: item.html.includes('href="/pwa-icons/icon-180x180.png"'),
    msTile: item.html.includes('content="/pwa-icons/icon-144x144.png"'),
    browser48: item.html.includes('href="/pwa-icons/icon-48x48.png"'),
    browser96: item.html.includes('href="/pwa-icons/icon-96x96.png"'),
    browser144: item.html.includes('href="/pwa-icons/icon-144x144.png"'),
    browser512: item.html.includes('href="/pwa-icons/icon-512x512.png"'),
    noLegacyShortcutIco: !item.html.includes('href="/favicon.ico"')
  }));
  const badHtml = htmlChecks.filter((item) => !item.manifestRootAbsolute || !item.touch120 || !item.touch152 || !item.touch167 || !item.touch180 || !item.msTile || !item.browser48 || !item.browser96 || !item.browser144 || !item.browser512 || !item.noLegacyShortcutIco);
  add(checks, 'html-manifest-and-touch-icons-root-absolute', badHtml.length === 0, { htmlChecks, badHtml });

  const missingSwIconTokens = EXPECTED_MANIFEST_ICON_PATHS.map((rel) => `/${rel}`).filter((token) => !sw.includes(`'${token}'`));
  add(checks, 'service-worker-precache-lists-manifest-icons-from-pwa-icons', sw.includes("'/manifest.json'") && missingSwIconTokens.length === 0 && !sw.includes("'/icons/") && !sw.includes("'/favicon.ico'"), {
    missingSwIconTokens
  });

  add(checks, 'service-worker-version-8P-2', sw.includes(`const SW_VERSION = '${EXPECTED_SW_VERSION}';`) && sw.includes("latestValidationStep: '8P-2'"), {
    expectedSwVersion: EXPECTED_SW_VERSION
  });

  const legacyIconReferenceFiles = ['manifest.json', 'index.html', 'docpro.html', 'steroidy.html', 'kalkulator-klirens.html', 'service-worker-kalorii.js'];
  const legacyIconReferences = legacyIconReferenceFiles.flatMap((file) => {
    const text = readText(file);
    return text.includes('/icons/') || text.includes('icons/favicon') || text.includes('/favicon.ico') ? [file] : [];
  });
  add(checks, 'no-legacy-icons-directory-or-favicon-ico-references', legacyIconReferences.length === 0, { legacyIconReferences });

  const failed = checks.filter((item) => item.ok !== true);
  return {
    ok: failed.length === 0,
    failedCount: failed.length,
    total: checks.length,
    step: STEP,
    name: 'pwa-manifest-icon-cache-smoke',
    canonicalIconDirectory: '/pwa-icons/',
    manifestIconCount: icons.length,
    expectedManifestIconCount: EXPECTED_MANIFEST_ICON_PATHS.length,
    shortcutUrls,
    checks,
    failed,
    scope: {
      readsFilesOnly: true,
      registeredRealServiceWorker: false,
      touchedBrowserCacheApi: false,
      touchedIndexedDb: false,
      performedNetworkFetch: false,
      changedClinicalData: false,
      changedGhIgfData: false
    }
  };
}

if (require.main === module) {
  try {
    const result = runPwaManifestIconCacheSmoke();
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    process.exit(result.ok ? 0 : 1);
  } catch (error) {
    const result = {
      ok: false,
      failedCount: 1,
      total: 1,
      step: STEP,
      name: 'pwa-manifest-icon-cache-smoke',
      error: error && error.stack ? error.stack : String(error)
    };
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    process.exit(1);
  }
}

module.exports = { runPwaManifestIconCacheSmoke };
